package com.edu;

public class AssignValuse {

	public static void main(String[] args) {
		int i=10;
		float f=78.4f;
		char ch='A';
		String s="Hello";
		double d=98.3;
		
		short sh=76;
		byte b=127;
		//System.out.println("Integer value i="+i); //no default values
		System.out.println("Float value f="+f);;
		
	}

}
