package com.edu;

public class MyDetails {

	public static void main(String[] args) {
		System.out.println("My Name is Madhuri");
		System.out.println("Studying in\t EduBridge");
		System.out.println("Java Fullstack");
		System.out.println();
	}
}
