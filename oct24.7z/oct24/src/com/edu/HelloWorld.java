package com.edu;
//import java.lang.*; //#include<stdio.h> 
//this package automatically imported by jvm
public class HelloWorld {  //

	public static void main(String[] args) {
		System.out.println("Hello world"); //to output we use System

	}

}

//orange color words are keywords
//HelloWorld ->user defined class
//String js predefined class