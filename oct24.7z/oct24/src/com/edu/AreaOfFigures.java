package com.edu;

public class AreaOfFigures {

	public static void main(String[] args) {
//		int b=3;
//		int h=9;
//		float a;
//		//a=(float)1/2*b*h; // 0.5*3*9
//		//a=0.5f*b*h;
//		a=(float)(b*h)/2; //27/2=13.5
//	
//		System.out.println("Area of Triangle "+a);
		
		int r=5;
		float area;
		
		//area=3.14159f*r*r;
		area = (float)22/7*r*r;
		
		System.out.println("Area of Circle ="+area);
		
		
	}

}
