package com.junitnn;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.*;

/*
 @BeforeAll
 @AfterAll
 @BeforeEach
 @AfterEach
 */
public class JunitAnnoEx {
	//@BeforeClass
	/*void beforeClassMethod() {  //error make the method as static
		System.out.println("Running......before class");
		
	}
 */
	
	/*@BeforeClass
	public static void beforeClassMethod() {  //error make the method as static
		System.out.println("Running......before class");
		
	}
 
	@AfterClass
	public static void afterClassMethod() {
		System.out.println("Afterclass..........");
	}*/
	
	@Test  //creates the instance of class the it runs all test cases
	public void test1() {
		String actual="Hello Junit";
		assertEquals("Hello Junit", actual);
		System.out.println("Inside test1");
	}

	
	public void add() {
		int s=3+4;
		
		assertEquals(s,7);
		System.out.println("Inside test2");
	}
	
	
}
